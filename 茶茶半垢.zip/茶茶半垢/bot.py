# -*- coding: utf-8 -*-
from Linephu.linepy import *; import time, threading; ts = time.time();cl = LINE(""); cl.log(cl.authToken); AuthToken = []
for i in range(1, 1): AuthToken.append(LINE(cl.authToken))
from datetime import datetime
from time import sleep
from humanfriendly import format_timespan, format_size, format_number, format_length
import requests
from bs4 import BeautifulSoup
import time, random, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, urllib, urllib.parse, timeit
from gtts import gTTS
from googletrans import Translator
from youtube_dl import YoutubeDL
import subprocess, youtube_dl
#==============================================================================#
botStart = time.time()
clMID = cl.profile.mid
profile = cl.getProfile()
status = str(profile.statusMessage)
lock = _name = "ČŤØ ŁÏŇË BøŤ運行中...\n✔BøŤ運行中...\n✔已運行24høuř\nČŕëäťøŕ:英豪\nČŕëäťøŕ ÍĎ:aa712205\n半垢版本:V3.0\n\n#==================#\n換頭區\n#==================#\n\n免費換影片頭貼\n"
if lock not in status:
    profile.statusMessage = lock + status
    cl.updateProfile(profile)
else:
    pass
settings = {
    "changePicture": True
}
clProfile = cl.getProfile()
clMID = cl.profile.mid
#KAC = [cl]
#Bots = [clMID]

clProfile = cl.getProfile()

lineSettings = cl.getSettings()

oepoll = OEPoll(cl)
#==============================================================================#
readOpen = codecs.open("read.json","r","utf-8")
settingsOpen = codecs.open("temp.json","r","utf-8")
banOpen = codecs.open("ban.json","r","utf-8")

read = json.load(readOpen)
settings = json.load(settingsOpen)
ban = json.load(banOpen)

bl = [""]
msg_dict = {}
msg_dictt = {}
restart = False
wait = {
    'logout': {},
    'rapidFire': {},
    'group': "",
    'getmid': False,
    'um': False,#收回高速
    'cvp': False,#更換頭貼
    'gbc':{},
    'resset': False#偵測更新
    }
#==============================================================================#
####################################################
mulai = time.time()
####################################################
def restartBot():
    print ("[柴柴系統半垢]機器重啟")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
def ytdl(url):
    video = pafy.new(url)
    best = video.getbest() 
    best.download(filepath="test.mp4")
def Runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d 天\n%02d 小時\n%02d 分鐘\n%02d 秒\n以上為半垢運行時間\n半垢 運行時間測試' % (days, hours, mins, secs)
def Runtimeself(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d天%02d小時%02d分鐘%02d秒' % (days, hours, mins, secs)
def backupData():
    try:
        backup = settings
        f = codecs.open('temp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = read
        f = codecs.open('read.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = ban
        f = codecs.open('ban.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False    
def logError(text):
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
def sendMessageWithMention(to, mid):
    try:
        aa = '{"S":"0","E":"3","M":'+json.dumps(mid)+'}'
        text_ = '@x '
        cl.sendMessage(to, text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
    except Exception as error:
        logError(error)
def sendMention(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@zeroxyuuki "
    if mids == []:
        raise Exception("Invaliod mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
            textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
def helpmessage():
    helpMessage = """===============
指令表本表
===============
[Help]查看本功能表
[Help1] 查看自身設定
[Help2] 查看機器設定
[Help3] 查看爬蟲邀請功能
[Help4] 查看權黑功能
[Help5] 查看群組功能
[Help6] 查看其他功能和換頭貼功能
[Help7] 查看踢人和專武功能
[Help8] 查看更新功能
===============
你以為還有嗎
==============="""
    return helpMessage
def helpmessagebot():
    helpMessageBOT = """===============
本機狀態
===============
➥Restart 重新啟動
➥Save 儲存設定
➥logout 選擇登出
➥Runtime 運作時間
➥tsp 速度測試表
➥Sp 速度
➥Set 設定
➥bye 機器退出群組
➥About 關於本帳
➥.Cn:(text) 更改名子
➥.Cb:(text) 更改個簽
➥lg 查看自己在的群組
===============
資訊
===============
➥Me 我的連結
➥MyMid 我的mid
➥MyName 我的名字
➥MyBio 個簽
➥MyPicture 我的頭貼
➥myvid 我的影片
➥MyCover 我的封面
➥Contact @ 標註取得連結
➥Mid @ 標註查mid
➥gc @ 簡單查看標註者資訊
➥contact @ 查看標註者友資
➥Name @ 完整查看標註者資訊"""
    return helpMessageBOT
def helpmessageset():
    helpMessageSET = """===============
設定
===============
➥Add On/Off 自動加友
➥Join On/Off 自動進群
➥Leave On/Off 離開副本
➥Read On/Off 自動已讀
➥Share On/Off 權限公開
➥Game On/Off 遊戲開啟/關閉
➥sp On/Off 入群頭貼
➥sl On/Off 入群通知
➥sj On/Off 退群通知
➥kc On/Off 踢人通知
➥ReRead On/Off 查詢收回
➥Pro On/Off 所有保護
➥pr On/Off 踢人保護
➥qr On/Off 網址保護
➥ip On/Off 邀請保護
➥Getmid On/Off 取得MID
➥Detect On/Off 標註偵測
➥cp on/off 偵測更新帳號 
➥Timeline On/Off 文章網址 """
    return helpMessageSET
def helpmessageme():
    helpMessageME = """===============
爬蟲
===============
➥youtube:
➥google:
===============
邀請
===============
➥Botsadd @ 加入自動邀請
➥Botsdel @ 取消自動邀請
➥Botslist 自動邀請表
➥Join 自動邀請
➥ii @ 次數  標註邀機
➥Inv (mid) 透過mid邀請
➥Inv @ 標註多邀"""
    return helpMessageME
def helpmessageban():
    helpMessageBAN = """===============
權黑指令
===============
➥op @ 新增權限
➥delop @ 刪除權限
➥Ban @ 加入黑單
➥Mb:mid 使用系統識別碼將該用戶加入黑單
➥Mub:mid 使用系統識別碼將該用戶解除黑單
➥Unban @ 取消黑單
➥Nkban 踢除黑單
➥CleanBan 清空黑單
➥oplist 查看權限表
➥Banlist 查看黑單"""
    return helpMessageBAN
def helpmessagegrp():
    helpMessageGRP = """===============
群組
===============
➥Group 創群者
➥GroupId 群組ID
➥GroupName 群組名稱
➥GroupPicture 群組圖片
➥GroupLink 群組網址
➥Link On/Off網址開/關
➥Lg 所有群組列表
➥Gb 成員名單
➥Ginfo 群組資料
➥Gn (文字) 更改群名
➥Cancel 取消所有邀請"""
    return helpMessageGRP
def helpmessageatl():
    helpMessageATL = """===============
其他
===============
➥Tagall 標註全體
➥Zc 發送0字元友資
➥SR 已讀點設置
➥DR 取消偵測
➥LR 已讀偵測
➥mall:次數 群組通話邀請
➥rall:次數 副本通話邀請
➥Say [內容 次數] 重複講話
➥Tag @ [次數] 重複標人
➥tr-Tw (text) 翻譯成中文
➥tr-En (text) 翻譯日文
➥tr-Jp (text) 翻譯英文
➥tr-Id (text)  翻譯印尼文
➥send-tw (text) 用中文說
➥send-en (text) 用英文說
➥send-jp (text) 用日文說
➥send-id (trxt) 用印尼文說
➥c:(MID) mid獲取友資
➥sc:(GROUP MID) GMID獲取群組資訊
➥Copy @ 複製標著者
➥us 急速收回訊息
===============
換頭貼功能
===============
➥cvp:YT影片網址"""
    return helpMessageATL
def helpmessagemin():
    helpMessageMIN = """===============
踢人
===============
➥Nk @ 單、多踢
➥Tk @ 單、多踢
➥Zk @ 單踢
➥nkban 踢除黑名單
➥Zk 踢出0字元
➥Tnk:(TEXT) 使用名字踢人
➥byeall翻群
➥Ri @ 來回機票
➥rk @ 來回機票
➥Tnk @ 標註加入預備剔除名單
➥kn @ 標註加入預備剔除名單
➥unk @ 標註取消預備剃除名單
➥klist 查看預備剃除名單
➥Tkk 踢出名單者
➥cleankill 清空預備剃除名單
===============
專武
===============
➥.tk 翻群
➥.ttk@ 專武多踢
➥.sp 專武準確測速"""
    return helpMessageMIN
def helpmessageadd():
    helpMessageADD = """===============
更新功能
===============
➥ii @ 次數  標註邀機
➥rk @ 來回機票
➥Tnk @ 標註加入預備剔除名單
➥kn @ 標註加入預備剔除名單
➥unk @ 標註取消預備剃除名單
➥klist 查看預備剃除名單
➥Tkk 踢出名單者
➥cleankill 清空預備剃除名單
➥c:(MID) mid獲取友資
➥sc:(GROUP MID) GMID獲取群組資訊
➥Copy @ 複製標著者
➥Cn:(text) 更改名子
➥Cb:(text) 更改個簽
➥lg 查看自己在的群組
➥Tnk:(TEXT) 使用名字踢人
➥logout 選擇登出
➥cp on/off  偵測更新帳號 
➥us 急速收回訊息"""
    return helpMessageADD
wait2 = {
    'readPoint':{},
    'readMember':{},
    'setTime':{},
    'ROM':{}
}
setTime = {}
setTime = wait2['setTime']
admin=[]
owners=['ueeb9eff8fe4804ea3e25a5d90b09fa7d','',clMID]
#if clMID not in owners:
#    python = sys.executable
#    os.execl(python, python, *sys.argv)
#==============================================================================#
def lineBot(op):
    try:
        if op.type == 0:
            return
        if op.type == 5:
            print ("[ 5 ] NOTIFIED ADD CONTACT")
            if settings["autoAdd"] == True:
                cl.findAndAddContactsByMid(op.param1)
                cl.sendMessage(op.param1, "安安！{} 感謝您加我為好友！".format(str(cl.getContact(op.param1).displayName)))
        if op.type == 1:
            print ("[ 1 ] 個簽鎖定")
            if cl.getProfile().mid != admin:
                if op.param1 == "16":
                    _name = "英豪 βộṱ \n\n"
                    _name += "英豪 βộṱ \n\n"
                    _name += "✔已運行 24høüř\n\n"
                    _name += "✔βộṱ  ℟Ǖ....\n\n"
                    _name += "Çręätør:英豪 \n\n\n"
                    _name += "Çręätør ĮD:aa712205 \n\n"
                    _name += "當前版本: \n\n"
                    contact = cl.getProfile()
                    status = contact.statusMessage
                    if _name not in  cl.getProfile().statusMessage:
                        profile = cl.getProfile()
                        profile.statusMessage =  _name + status
#                        cl.updateProfile(profile)
        if op.type == 2:
            contact = cl.getContact(op.param1)
            if wait["resset"] == True:
                if op.param2 == "2":
                    cl.sendMessage(op.param1,"[自動發送]\n抓到更改名稱摟!!!\n作者:英豪\n")
                    cl.sendMessage("MID","通知好友更改名稱:\n" + contact.displayName)
                if op.param2 == "8":
                    cl.sendMessage(op.param1,"[自動發送]\n抓到更改頭貼/動態頭貼摟!!!\n作者:英豪\n")
                    cl.sendMessage("MID","通知好友更改動態頭貼:\n" + contact.displayName)
                if op.param2 == "16":
                    cl.sendMessage(op.param1,"[自動發送]\n抓到更改個簽摟!!!\n作者:英豪\n")
                    cl.sendMessage("MID","通知好友更改個簽:\n" + contact.displayName)
        if op.type == 11:
            group = cl.getGroup(op.param1)
            contact = cl.getContact(op.param2)
            if settings["qrprotect"] == True:
                if op.param2 in admin or op.param2 in ban["bots"]:
                    pass
                else:
                    gs = cl.getGroup(op.param1)
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    gs.preventJoinByTicket = True
                    cl.updateGroup(gs)
        if op.type == 13:
            print ("[ 13 ] NOTIFIED INVITE GROUP")
            if clMID in op.param3:
                group = cl.getGroup(op.param1)
                if settings["autoJoin"] == True:
                    if op.param2 in admin or op.param2 in owners:
                       cl.acceptGroupInvitation(op.param1)
                       cl.sendMessage(op.param1,"☰☱☲☳自動入群☴☵☶☷\n英豪βộṱ 自動入群\n感謝權限者邀請入群\nÇręätør：英豪\n\n☰☱☲☳結束☴☵☶☷")
                else:
                    cl.acceptGroupInvitation(op.param1)
                    cl.sendMessage(op.param1, "☰☱☲☳自動入群☴☵☶☷\n英豪βộṱ 自動入群\n#非權限者邀請入群...自動退群\nÇręätør：英豪\n\n☰☱☲☳結束☴☵☶☷")
                    cl.leaveGroup(op.param1)
            else:
                group = cl.getGroup(op.param1)
                gInviMids = []
                for z in group.invitee:
                    if z.mid in ban["blacklist"]:
                        gInviMids.append(z.mid)
                if gInviMids == []:
                    pass
                else:
                    cl.cancelGroupInvitation(op.param1, gInviMids)
                    cl.sendMessage(op.param1,"被邀請者在黑名單...")
        if op.type == 15:
            contact1 = cl.getContact(op.param2)
            group = cl.getGroup(op.param1)
            if settings["seeLeave"] == True:
                try:
                    arrData = ""
                    text = "%s "%('提示')
                    arr = []
                    mention = "@x "
                    slen = str(len(text))
                    elen = str(len(text) + len(mention) - 1)
                    arrData = {'S':slen, 'E':elen, 'M':op.param2}
                    arr.append(arrData)
                    text += mention + "退出了 {} ！".format(str(group.name))
                    cl.sendMessage(op.param1,text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
                except Exception as error:
                    print(error)
        if op.type == 17:
            contact1 = cl.getContact(op.param2)
            group = cl.getGroup(op.param1)
            if settings["seeJoin"] == True:
                try:
                    arrData = ""
                    text = "%s "%('歡迎')
                    arr = []
                    mention = "@x "
                    name = str(cl.getGroup(op.param1).name)
                    slen = str(len(text))
                    elen = str(len(text) + len(mention) - 1)
                    arrData = {'S':slen, 'E':elen, 'M':op.param2}
                    arr.append(arrData)
                    text += mention + "\n加入 {} 的大家庭! ".format(str(group.name))
                    cl.sendMessage(op.param1,text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
                except Exception as error:
                    print(error)
        if op.type == 19:
            contact1 = cl.getContact(op.param2)
            group = cl.getGroup(op.param1)
            contact2 = cl.getContact(op.param3)
            if settings["protect"] == True:
                if op.param2 in admin:
                    pass
                else:
                    if settings["kickContact"] == True:
                        try:
                            arrData = ""
                            text = "%s " %('警告')
                            arr = []
                            mention1 = "@arasi "
                            slen = str(len(text))
                            elen = str(len(text) + len(mention1) - 1)
                            arrData = {'S':slen, 'E':elen, 'M':op.param2}
                            arr.append(arrData)
                            text += mention1 + '踢了 '
                            mention2 = "@kick "
                            sslen = str(len(text))
                            eelen = str(len(text) + len(mention2) - 1)
                            arrdata = {'S':sslen, 'E':eelen, 'M':op.param3}
                            arr.append(arrdata)
                            text += mention2
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            settings["blacklist"][op.param2] = True
                            cl.sendMessage(op.param1,text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
                        except Exception as error:
                            print(error)
                    else:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        settings["blacklist"][op.param2] = True
            else:
                if settings["kickContact"] == True:
                    try:
                        arrData = ""
                        text = "%s " %('警告')
                        arr = []
                        mention1 = "@arasi "
                        slen = str(len(text))
                        elen = str(len(text) + len(mention1) - 1)
                        arrData = {'S':slen, 'E':elen, 'M':op.param2}
                        arr.append(arrData)
                        text += mention1 + '踢了 '
                        mention2 = "@kick "
                        sslen = str(len(text))
                        eelen = str(len(text) + len(mention2) - 1)
                        arrdata = {'S':sslen, 'E':eelen, 'M':op.param3}
                        arr.append(arrdata)
                        text += mention2
                        cl.sendMessage(op.param1,text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
                    except Exception as error:
                        print(error)
                else:
                     pass
        if op.type == 24:
            print ("[ 24 ] NOTIFIED LEAVE ROOM")
            if settings["autoLeave"] == True:
                cl.leaveRoom(op.param1)
        if op.type == 25 or op.type == 26:
            K0 = admin
            msg = op.message
            if settings["share"] == True:
                K0 = msg._from
            else:
                K0 = admin
#        if op.type == 25 :
#            if msg.toType ==2:
#                g = cl.getGroup(op.message.to)
#                print ("sended:".format(str(g.name)) + str(msg.text))
#            else:
#                print ("sended:" + str(msg.text))
#        if op.type == 26:
#            msg =op.message
#            pop = cl.getContact(msg._from)
#            print ("replay:"+pop.displayName + ":" + str(msg.text))
        if op.type == 26 or op.type == 25:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
            if sender in sender:
                if text.lower() == '遊戲':        
                    if settings["newGame"] == True:
                        cl.sendReplyMessage(msg.id, to,"[遊戲內容]\n運勢\n猜拳\n音樂[=感謝使用=]")
            if sender in sender:
                if text.lower() == '運勢':        
                    if settings["newGame"] == True:
                        data = random.choice(['[運勢結果]\n撿到100元～有點手氣！','[運勢結果]\n撿到500元～運氣可以^_^','[運勢結果]\n撿到50元～有點不好...','[運勢結果]\n沒撿到～慘了慘了...','[運勢結果]\n撿到1000元～手氣旺旺！'])
                        cl.sendReplyMessage(msg.id, to,str(data))
            if sender in sender:
                if text.lower() == '音樂':        
                    if settings["newGame"] == True:
                        data = random.choice(['[推薦音樂]\nhttps://youtu.be/vWcVQZ-NQsg','[推薦音樂]\nhttps://youtu.be/a4eR-5OJ-7Q','[推薦音樂]\nhttps://youtu.be/b35Vwj0aFxY','[推薦音樂]\nhttps://youtu.be/ryP_nQYYaYY','[推薦音樂]\nhttps://youtu.be/Hl3L9_VK7wM','[推薦音樂]\nhttps://youtu.be/ATblV50Odx8','[推薦音樂]\nhttps://youtu.be/Kc5BCtfFzDg','[推薦音樂]\nhttps://youtu.be/TQ5w9KHHa9M','[推薦音樂]\nhttps://youtu.be/yjM25-Z38_4','[推薦音樂]\nhttps://youtu.be/wdH26D8Ssww','[推薦音樂]\nhttps://youtu.be/jfzOlIVBGzM','[推薦音樂]\nhttps://youtu.be/iIF2ikZfoxw','[推薦音樂]\nhttps://youtu.be/WmW9Fh4Msu4','[推薦音樂]\nhttps://youtu.be/kO77K3dEMpA','[推薦音樂]\nhttps://youtu.be/_9gvo2aClpk','[推薦音樂]\nhttps://youtu.be/aAkMkVFwAoo','[推薦音樂]\nhttps://youtu.be/VhHQyb4r9Xg','[推薦音樂]\nhttps://youtu.be/xrooMGuRhgY','[推薦音樂]\nhttps://youtu.be/ZeN007qFHFM'])
                        cl.sendReplyMessage(msg.id, to,str(data))
            if sender in sender:
                if text.lower() == '猜拳':
                    if settings["newGame"] == True:
                        cl.sendReplyMessage(msg.id, to, "[猜拳遊戲]\n輸入：\n剪刀，石頭，布\n\n來一決高下吧！")
            if sender in sender:
                if text.lower() == '剪刀':        
                    if settings["newGame"] == True:
                        data = random.choice(['[猜拳結果]\n你出剪刀✌\n我出石頭👊\n\n👻你輸了-垃圾！👻','[猜拳結果]\n你出剪刀✌\n我出布✋\n\n🎉你贏了-滾拉！🎉','[猜拳結果]\n你出剪刀✌\n我出剪刀✌\n\n👏平手-算你好運！👏'])
                        cl.sendReplyMessage(msg.id, to,str(data))
            if sender in sender:
                if text.lower() == '石頭':        
                    if settings["newGame"] == True:
                        data = random.choice(['[猜拳結果]\n你出石頭👊\n我出石頭👊\n\n👏平手！-想贏嗎?👏','[猜拳結果]\n你出石頭👊\n我出布✋\n\n👻你輸了！-笑死👻','[猜拳結果]\n你出石頭👊\n我出剪刀✌\n\n🎉你贏了！-阿不就很邱🎉'])
                        cl.sendReplyMessage(msg.id, to,str(data))  
            if sender in sender:
                if text.lower() == '布':        
                    if settings["newGame"] == True:
                        data = random.choice(['[猜拳結果]\n你出布✋\n我出石頭\n\n🎉你贏了！-剛好而已🎉','[猜拳結果]\n你出布✋\n我出布✋\n\n👏平手！-喔👏','[猜拳結果]\n你出布✋\n我出剪刀✌\n\n👻你輸了！-知道了嗎👻'])
                        cl.sendReplyMessage(msg.id, to,str(data))                
#==============================================================================#
            if sender in K0 or sender in owners:
                if text.lower() == 'help':
                    helpMessage = helpmessage()
                    cl.sendReplyMessage(msg.id, to, str(helpMessage))
                if text.lower() == 'help1':
                    helpMessageBOT = helpmessagebot()
                    cl.sendReplyMessage(msg.id, to, str(helpMessageBOT))
                if text.lower() == 'help2':
                    helpMessageSET = helpmessageset()
                    cl.sendReplyMessage(msg.id, to, str(helpMessageSET))
                if text.lower() == 'help3':
                    helpMessageME = helpmessageme()
                    cl.sendReplyMessage(msg.id, to, str(helpMessageME))
                if text.lower() == 'help4':
                    helpMessageBAN = helpmessageban()
                    cl.sendReplyMessage(msg.id, to, str(helpMessageBAN))
                if text.lower() == 'help5':
                    helpMessageGRP = helpmessagegrp()
                    cl.sendReplyMessage(msg.id, to, str(helpMessageGRP))
                if text.lower() == 'help6':
                    helpMessageATL = helpmessageatl()
                    cl.sendReplyMessage(msg.id, to, str(helpMessageATL))
                if text.lower() == 'help7':
                    helpMessageMIN = helpmessagemin()
                    cl.sendReplyMessage(msg.id, to, str(helpMessageMIN))
                if text.lower() == 'help8':
                    helpMessageADD = helpmessageadd()
                    cl.sendReplyMessage(msg.id, to, str(helpMessageADD))
            
#==============================================================================#
                elif text.lower() == 'spt':
                    cl.sendReplyMessage(msg.id, to,"結果約為\n"+str(timeit.timeit('"-".join(str(n) for n in range(100))',number=1000)) + "秒")
                elif text.lower() == 'bye':
                    cl.sendReplyMessage(msg.id, to, "各位bye~，有緣再見❤️")
                    cl.leaveGroup(msg.to)
                elif text.lower() == 'tsp':
                    ret_ = "［ 機器反應速度 ］"
                    ret_ += "\n第一次:\n"+str(timeit.timeit('"-".join(str(n) for n in range(100))',number=1000))
                    ret_ += "\n第二次:\n"+str(timeit.timeit('"-".join(str(n) for n in range(100))',number=1000))
                    ret_ += "\n第三次:\n"+str(timeit.timeit('"-".join(str(n) for n in range(100))',number=1000))
                    ret_ += "\n第四次:\n"+str(timeit.timeit('"-".join(str(n) for n in range(100))',number=1000))
                    ret_ += "\n第五次:\n"+str(timeit.timeit('"-".join(str(n) for n in range(100))',number=1000))
                    ret_ += "\n［ 機器處理速度 ］"
                    ret_ += "\n第一次:\n"+str(timeit.timeit('"-".join(str(n) for n in range(100))',number=1000))
                    ret_ += "\n第二次:\n"+str(timeit.timeit('"-".join(str(n) for n in range(100))',number=1000))
                    ret_ += "\n第三次:\n"+str(timeit.timeit('"-".join(str(n) for n in range(100))',number=1000))
                    ret_ += "\n第四次:\n"+str(timeit.timeit('"-".join(str(n) for n in range(100))',number=1000))
                    ret_ += "\n第五次:\n"+str(timeit.timeit('"-".join(str(n) for n in range(100))',number=1000))
                    ret_ += "\n［ 速度測試結束 ］"
                    cl.sendReplyMessage(msg.id, to, str(ret_))
                elif text.lower() == 'sp':
                    cl.sendReplyMessage(msg.id, to,"查詢結果\n"+str(timeit.timeit('"-".join(str(n) for n in range(100))',number=1000)) + "秒")
                elif text.lower() == 'save':
                    backupData()
                    cl.sendReplyMessage(msg.id, to,"儲存設定成功!")
                elif text.lower() == 'restart':
                    cl.sendReplyMessage(msg.id, to, "重新啟動中...")
                    time.sleep(5)
                    cl.sendReplyMessage(msg.id, to, "重新啟動成功\n\n重新啟動版本《V3.0》")
                    restartBot()
                elif text.lower() == 'rs':
                    cl.sendReplyMessage(msg.id, to, "重新啟動中...")
                    time.sleep(5)
                    cl.sendReplyMessage(msg.id, to, "重新啟動成功\n\n重新啟動版本《V3.0》")
                    restartBot()
                elif text.lower() == 'runtime':
                    eltime = time.time() - mulai
                    bot = "運行時間長達\n" + Runtime(eltime)
                    cl.sendReplyMessage(msg.id, to,bot)             
                elif text.lower() == 'about':
                    try:
                        cl.kickoutFromGroup(to,["HEY"])
                        cl.inviteIntoGroup(to, ["HEY"])
                    
                    except Exception as e:
                        if e.reason == "request blocked":
                            aa = "無法執行(規制)"
                        else:
                            aa = "可以執行(無規制)"
                        arr = []
                        owner ="ueeb9eff8fe4804ea3e25a5d90b09fa7d"
                        creator = cl.getContact(owner)
                        contact = cl.getContact(clMID)
                        grouplist = cl.getGroupIdsJoined()
                        contactlist = cl.getAllContactIds()
                        blockedlist = cl.getBlockedContactIds()
                        clProfile = cl.getProfile()
                        clSetting = cl.getSettings()
                        eltime = time.time() - mulai
                        timeNow = datetime.now()
                        timE = datetime.strftime(timeNow,"%H:%M:%S")
                        bot = "" + Runtimeself(eltime)
                        ret_ = "☴☵☶☷關於自己☴☵☶☷"
                        ret_ += "\n➥群組數量: {}".format(str(len(grouplist)))
                        ret_ += "\n➥好友人數: {}".format(str(len(contactlist)))
                        ret_ += "\n➥封鎖人數: {}".format(str(len(blockedlist)))
                        ret_ += "\n➥個簽字數: {}".format(str(len(clProfile.statusMessage)))
                        ret_ += "\n➥最愛人數: {}".format(str(len(cl.getFavoriteMids())))
                        ret_ += "\n➥封鎖好友: {}".format(str(len(cl.getBlockedContactIds())))
                        ret_ += "\n➥邀請群組: {}".format(str(len(cl.getGroupIdsInvited())))
                        ret_ += "\n➥Line帳號ID:\n☆{}".format(clProfile.userid)
                        ret_ += "\n➥個人名稱:\n☆{}".format(contact.displayName)
                        ret_ += "\n➥個人網址(一):\nN".format(str(clProfile.userid))
                        ret_ += "\n➥個人網址(二):\nN".format(str(clSetting.contactMyTicket))
                        ret_ += "\n➥識別碼:\n☆{}".format(str(clProfile.mid))
                        ret_ += "\n☴☵☶☷狀態規制☴☵☶☷"
                        ret_ += "\n➥踢人狀態: {}".format(aa)
                        ret_ += "\n➥邀請狀態: {}".format(aa)
                        ret_ += "\n➥取消狀態: 可以執行(無規制)"
                        ret_ += "\n☴☵☶☷部分設定☴☵☶☷"
                        if settings["autoAdd"] == True: ret_ += "\n☆自動加友 ✅"
                        else: ret_ += "\n☆自動加友 ❌"
                        if settings["autoJoin"] == True: ret_ += "\n☆自動入群 ✅"
                        else: ret_ += "\n☆自動入群 ❌"
                        if settings["autoLeave"] == True: ret_ += "\n☆自離副本 ✅"
                        else: ret_ += "\n☆自離副本 ❌"
                        if settings["autoRead"] == True: ret_ += "\n☆自動已讀 ✅"
                        else: ret_ += "\n☆自動已讀 ❌"
                        if settings["newGame"] ==True: ret_+="\n☆遊戲公開 ✅"
                        else: ret_ += "\n☆遊戲公開 ❌"
                        if settings["seeJoin"] == True: ret_ += "\n☆入群通知 ✅"
                        else: ret_ += "\n☆入群通知 ❌"
                        if settings["poilfe"] == True: ret_ += "\n☆入群頭貼 ✅"
                        else: ret_ += "\n☆入群頭貼 ❌"
                        if settings["seeLeave"] == True: ret_ += "\n☆退群通知 ✅"
                        else: ret_ += "\n☆退群通知 ❌"
                        if settings["kickContact"] == True: ret_ += "\n☆踢人通知 ✅"
                        else: ret_ += "\n☆踢人通知 ❌"
                        ret_ += "\n☰☱☲☳關於作者☴☵☶☷"
                        ret_ += "\n➥Çręätør : 英豪"
                        ret_ += "\n➥Çręätør ĮD aa712205"
                        ret_ += "\n➥作者網址：\nN"
                        ret_ += "\n☰☱☲☳關於bot☴☵☶☷"
                        ret_ += "\n➥版本 : 【英豪】"
                        ret_ += "\n➥預備線程數 : 【10】"
                        ret_ += "\n➥連線線程數 : 【1】"
                        ret_ += "\n➥半垢反應速度：\n【{}】".format(str(timeit.timeit('"-".join(str(n) for n in range(100))',number=1000)))
                        ret_ += "\n➥運行時間長達：\n【{}】".format(str(bot))
                        ret_ += "\n➥查詢時間：【{}】".format(str(timE))
                        ret_ += "\n☰☱☲☳作者友資☴☵☶☷"
                        cl.sendReplyMessage(msg.id, to, str(ret_))
                        cl.sendContact(to, "ueeb9eff8fe4804ea3e25a5d90b09fa7d")
                    except Exception as e:
                        cl.sendMessage(msg.to, str(e))
#==============================================================================#
                elif text.lower() == 'set':
                    try:
                        ret_ = "[ 狀態 ]"
                        if settings["autoAdd"] == True: ret_ += "\n☆自動加友 ✅"
                        else: ret_ += "\n☆自動加友 ❌"
                        if settings["autoJoin"] == True: ret_ += "\n☆自動入群 ✅"
                        else: ret_ += "\n☆自動入群 ❌"
                        if settings["autoLeave"] == True: ret_ += "\n☆自離副本 ✅"
                        else: ret_ += "\n☆自離副本 ❌"
                        if settings["autoRead"] == True: ret_ += "\n☆自動已讀 ✅"
                        else: ret_ += "\n☆自動已讀 ❌"
                        if settings["timeline"] == True: ret_ += "\n☆文章預覽 ✅"
                        else: ret_ += "\n☆文章預覽 ❌"
                        if settings["getmid"] == True: ret_ += "\n☆獲取MID ✅"
                        else: ret_ += "\n☆獲取MID ❌"
                        if settings["protect"] ==True: ret_+="\n☆群組保護 ✅"
                        else: ret_ += "\n☆群組保護 ❌"
                        if settings["qrprotect"] ==True: ret_+="\n☆網址保護 ✅"
                        else: ret_ += "\n☆網址保護 ❌"
                        if settings["invprotect"] ==True: ret_+="\n☆邀請保護 ✅"
                        else: ret_ += "\n☆邀請保護 ❌"
                        if settings["detectMention"] ==False: ret_+="\n☆標註回覆 ✅"
                        else: ret_ += "\n☆標註回覆 ❌"
                        if settings["reread"] ==True: ret_+="\n☆查詢收回 ✅"
                        else: ret_ += "\n☆查詢收回 ❌"
                        if settings["seeJoin"] == True: ret_ += "\n☆入群通知 ✅"
                        else: ret_ += "\n☆入群通知 ❌"
                        if settings["poilfe"] == True: ret_ += "\n☆入群頭貼 ✅"
                        else: ret_ += "\n☆入群頭貼 ❌"
                        if settings["seeLeave"] == True: ret_ += "\n☆退群通知 ✅"
                        else: ret_ += "\n☆退群通知 ❌"
                        if settings["kickContact"] == True: ret_ += "\n☆踢人通知 ✅"
                        else: ret_ += "\n☆踢人通知 ❌"
                        if settings["newGame"] ==True: ret_+="\n☆遊戲公開 ✅"
                        else: ret_ += "\n☆遊戲公開 ❌"
                        if settings["share"] ==True: ret_+="\n☆權限公開 ✅"
                        else: ret_ += "\n☆權限公開 ❌"
                        ret_ += "\n[ 完成 ]"
                        cl.sendReplyMessage(msg.id, to, str(ret_))
                    except Exception as e:
                        cl.sendMessage(msg.to, str(e))
                elif text.lower() == 'cp on':
                    wait["resset"] = True
                    cl.sendMessage(to, "偵測更新帳號\n名子✘/圖片✘/個簽✘\n更新為開啟偵測狀態✔\n名子✔/圖片✔/個簽✔")	
                elif text.lower() == 'cp off':
                    wait["resset"] = False
                    cl.sendMessage(to, "偵測更新帳號\n名子✔/圖片✔/個簽✔\n更新為關閉偵測狀態✘\n名子✘/圖片✘/個簽✘")
                elif text.lower() == 'add on':
                    settings["autoAdd"] = True
                    cl.sendReplyMessage(msg.id, to, "自動加入好友已開啟")
                elif text.lower() == 'add off':
                    settings["autoAdd"] = False
                    cl.sendReplyMessage(msg.id, to, "自動加入好友已關閉")
                elif text.lower() == 'join on':
                    settings["autoJoin"] = True
                    cl.sendReplyMessage(msg.id, to, "自動加入群組已開啟")
                elif text.lower() == 'join off':
                    settings["autoJoin"] = False
                    cl.sendReplyMessage(msg.id, to, "自動加入群組已關閉")
                elif text.lower() == 'leave on':
                    settings["autoLeave"] = True
                    cl.sendReplyMessage(msg.id, to, "自動離開副本已開啟")
                elif text.lower() == 'leave off':
                    settings["autoLeave"] = False
                    cl.sendReplyMessage(msg.id, to, "自動離開副本已關閉")
                elif text.lower() == 'read on':
                    settings["autoRead"] = True
                    cl.sendReplyMessage(msg.id, to, "自動已讀已開啟")
                elif text.lower() == 'read off':
                    settings["autoRead"] = False
                    cl.sendReplyMessage(msg.id, to, "自動已讀已關閉")
                elif text.lower() == 'reread on':
                    settings["reread"] = True
                    cl.sendReplyMessage(msg.id, to, "查詢收回開啟")
                elif text.lower() == 'reread off':
                    settings["reread"] = False
                    cl.sendReplyMessage(msg.id, to, "查詢收回關閉")
                elif text.lower() == 'pr on':
                    settings["protect"] = True
                    cl.sendReplyMessage(msg.id, to, "踢人保護開啟")
                elif text.lower() == 'pr off':
                    settings["protect"] = False
                    cl.sendReplyMessage(msg.id, to,"踢人保護關閉")
                elif text.lower() == 'game on':
                    settings["newGame"] = True
                    cl.sendReplyMessage(msg.id, to, "已開啟遊戲")
                elif text.lower() == 'game off':
                    settings["newGame"] = False
                    cl.sendReplyMessage(msg.id, to, "已關閉遊戲")
                elif text.lower() == 'share on':
                    settings["share"] = True
                    cl.sendReplyMessage(msg.id, to, "已開啟分享")
                elif text.lower() == 'share off':
                    settings["share"] = False
                    cl.sendReplyMessage(msg.id, to, "已關閉分享")
                elif text.lower() == 'detect on':
                    settings["detectMention"] = False
                    cl.sendReplyMessage(msg.id, to, "已開啟標註偵測")
                elif text.lower() == 'detect off':
                    settings["detectMention"] = True
                    cl.sendReplyMessage(msg.id, to, "已關閉標註偵測")
                elif text.lower() == 'qr on':
                    settings["qrprotect"] = True
                    cl.sendReplyMessage(msg.id, to, "網址保護開啟")
                elif text.lower() == 'qr off':
                    settings["qrprotect"] = False
                    cl.sendReplyMessage(msg.id, to, "網址保護關閉")
                elif text.lower() == 'ip on':
                    settings["invprotect"] = True
                    cl.sendReplyMessage(msg.id, to, "邀請保護開啟")
                elif text.lower() == 'ip off':
                    settings["invprotect"] = False
                    cl.sendReplyMessage(msg.id, to, "邀請保護關閉")
                elif text.lower() == 'getmid on':
                    settings["getmid"] = True
                    cl.sendReplyMessage(msg.id, to, "mid獲取開啟")
                elif text.lower() == 'getmid off':
                    settings["getmid"] = False
                    cl.sendReplyMessage(msg.id, to, "mid獲取關閉")
                elif text.lower() == 'timeline on':
                    settings["timeline"] = True
                    cl.sendReplyMessage(msg.id, to, "文章預覽開啟")
                elif text.lower() == 'timeline off':
                    settings["timeline"] = False
                    cl.sendReplyMessage(msg.id, to, "文章預覽關閉")
                elif text.lower() == 'sj on':
                    settings["seeJoin"] = True
                    cl.sendReplyMessage(msg.id, to, "入群通知已開啟")
                elif text.lower() == 'sj off':
                    settings["seeJoin"] = False
                    cl.sendReplyMessage(msg.id, to, "入群通知已關閉")
                elif text.lower() == 'sp on':
                    settings["poilfe"] = True
                    cl.sendReplyMessage(msg.id, to, "入群頭貼已開啟")
                elif text.lower() == 'sp off':
                    settings["poilfe"] = False
                    cl.sendReplyMessage(msg.id, to, "入群頭貼已關閉")
                elif text.lower() == 'sl on':
                    settings["seeLeave"] = True
                    cl.sendReplyMessage(msg.id, to, "退群通知已開啟")
                elif text.lower() == 'sl off':
                    settings["seeLeave"] = False
                    cl.sendReplyMessage(msg.id, to, "退群通知已關閉")
                elif text.lower() == 'kc on':
                    settings["kickContact"] = True
                    cl.sendReplyMessage(msg.id, to, "踢人標註已開啟")
                elif text.lower() == 'kc off':
                    settings["kickContact"] = False
                    cl.sendReplyMessage(msg.id, to, "踢人標註已關閉")
                elif text.lower() == 'pro on':
                    settings["protect"] = True
                    settings["qrprotect"] = True
                    settings["invprotect"] = True
                    cl.sendMessage(to, "踢人保護開啟")
                    cl.sendMessage(to, "網址保護開啟")
                    cl.sendMessage(to, "邀請保護開啟")
                elif text.lower() == 'pro off':
                    settings["protect"] = False
                    settings["qrprotect"] = False
                    settings["invprotect"] = False
                    cl.sendMessage(to, "踢人保護關閉")
                    cl.sendMessage(to, "網址保護關閉")
                    cl.sendMessage(to, "邀請保護關閉")
#==============================================================================#
                elif msg.text.lower().startswith("op "):
                    MENTION = eval(msg.contentMetadata['MENTION'])
                    inkey = MENTION['MENTIONEES'][0]['M']
                    admin.append(str(inkey))
                    cl.sendReplyMessage(msg.id, to, "已獲得權限！")
                elif msg.text.lower().startswith("delop "):
                    MENTION = eval(msg.contentMetadata['MENTION'])
                    inkey = MENTION['MENTIONEES'][0]['M']
                    admin.remove(str(inkey))
                    cl.sendReplyMessage(msg.id, to, "已取消權限！")
                elif text.lower() == '現在時間':
                    if sender in Owner:
                        tz = pytz.timezone("Asia/Taipei")	
                        timeNow = datetime.now(tz=tz)
                        day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                        hari = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"]
                        bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                        hr = timeNow.strftime("%A")
                        bln = timeNow.strftime("%m")
                        for i in range(len(day)):
                            if hr == day[i]: hasil = hari[i]
                        for k in range(0, len(bulan)):
                            if bln == str(k): bln = bulan[k-1]
                        readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\n時間 : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                        cl.sendReplyMessage(msg.to, readTime)
                elif "checkdate" in msg.text.lower():
                    if sender in Owner:
                        sep = msg.text.split(" ")
                        tanggal = msg.text.replace(sep[0] + " ","")
                        r=requests.get('https://script.google.com/macros/exec?service=AKfycbw7gKzP-WYV2F5mc9RaR7yE3Ve1yN91Tjs91hp_jHSE02dSv9w&nama=ervan&tanggal='+tanggal)
                        data=r.text
                        data=json.loads(data)
                        ret_ = "╔══[ 日期 ]"
                        ret_ += "\n╠ 出生日期 : {}".format(str(data["data"]["lahir"]))
                        ret_ += "\n╠ 年齡 : {}".format(str(data["data"]["usia"]))
                        ret_ += "\n╠ 生日 : {}".format(str(data["data"]["ultah"]))
                        ret_ += "\n╠ Zodiak : {}".format(str(data["data"]["zodiak"]))
                        ret_ += "\n╚══[ 完成 ]"
                        cl.sendReplyMessage(to, str(ret_))
                elif "searchimage" in msg.text.lower():
                    if sender in Owner:
                        separate = msg.text.split(" ")
                        search = msg.text.replace(separate[0] + " ","")
                        with requests.session() as web:
                            web.headers["User-Agent"] = random.choice(settings["userAgent"])
                            r = web.get("http://rahandiapi.herokuapp.com/imageapi?key=betakey&q={}".format(urllib.parse.quote(search)))
                            data = r.text
                            data = json.loads(data)
                            if data["result"] != []:
                                items = data["result"]
                                path = random.choice(items)
                                a = items.index(path)
                                b = len(items)
                                cl.sendReplyImageWithURL(to, str(path))
                elif "youtube:" in msg.text:
                    number = text.replace("youtube:","")
                    url = "https://m.youtube.com/results?search_query={}".format(number)
                    request = requests.get(url)
                    content = request.content
                    soup = BeautifulSoup(content, "html.parser")
                    ret_ = "—YouTube搜尋結果—"
                    no = 0 + 1
                    for all_mv in soup.select(".yt-lockup-video"):
                         name = all_mv.select("a[rel='spf-prefetch']")
                         ret_ += "\n\n =====[ {} ]====={}\n\n https://www.youtube.com{}".format(str(no), str(name[0].get("title")), str(name[0].get("href")))
                         no += 1
                    cl.sendReplyMessage(msg.id, to, str(ret_))
                elif text.lower() == 'oplist':
                    if admin == []:
                        cl.sendReplyMessage(msg.id, to,"無擁有權限者!")
                    else:
                        mc = "[ 權限者  ]"
                        for mi_d in admin:
                            mc += "\n☆➥"+cl.getContact(mi_d).displayName
                        cl.sendReplyMessage(msg.id, to,mc + "\n[ 結束  ]")
                elif msg.text.lower().startswith("invite "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    G = cl.getGroup
                    cl.inviteIntoGroup(to,targets)
                elif ("Say " in msg.text):
                    x = text.split(' ',2)
                    c = int(x[2])
                    for c in range(c):
                        cl.sendMessage(to,x[1])
                elif msg.text.lower().startswith("tag "):
                    MENTION = eval(msg.contentMetadata['MENTION'])
                    inkey = MENTION['MENTIONEES'][0]['M']
                    x = text.split(' ',2)
                    c = int(x[2])
                    for c in range(c):
                        sendMessageWithMention(to, inkey)
                elif ("Rex " in msg.text):
                    x = text.split(' ',2)
                    c = int(x[2])
                    for c in range(c):
                        cl.sendReplyMessage(msg.id, to,x[1])
                elif msg.text.lower().startswith("mex "):
                    MENTION = eval(msg.contentMetadata['MENTION'])
                    inkey = MENTION['MENTIONEES'][0]['M']
                    x = text.split(' ',2)
                    c = int(x[2])
                    for c in range(c):
                        cl.sendReplyMessage(msg.id, to, inkey)
                elif msg.text.lower().startswith("tex "):
                    MENTION = eval(msg.contentMetadata['MENTION'])
                    inkey = MENTION['MENTIONEES'][0]['M']
                    x = text.split(' ',2)
                    c = int(x[2])
                    for c in range(c):
                        cl.sendReplyMessageWithMention(msg.id, to, inkey)
                elif msg.text.lower().startswith("botsadd "):
                    MENTION = eval(msg.contentMetadata['MENTION'])
                    inkey = MENTION['MENTIONEES'][0]['M']
                    ban["bots"].append(str(inkey))
                    cl.sendReplyMessage(msg.id, to, "已加入分機！")
                elif msg.text.lower().startswith("botsdel "):
                    MENTION = eval(msg.contentMetadata['MENTION'])
                    inkey = MENTION['MENTIONEES'][0]['M']
                    ban["bots"].remove(str(inkey))
                    cl.sendReplyMessage(msg.id, to, "已取消分機！")
                elif text.lower() == 'botslist':
                    if ban["bots"] == []:
                        cl.sendMessage(to,"無分機!")
                    else:
                        mc = "╔══[ 邀請名單 ]"
                        for mi_d in ban["bots"]:
                            mc += "\n╠ "+cl.getContact(mi_d).displayName
                        cl.sendReplyMessage(msg.id, to,mc + "\n╚══[ 完成 ]")
                elif text.lower() == 'join':
                    if msg.toType == 2:
                        G = cl.getGroup
                        cl.inviteIntoGroup(to,ban["bots"])
                elif msg.text.lower().startswith("ii "):
                    MENTION = eval(msg.contentMetadata['MENTION'])
                    inkey = MENTION['MENTIONEES'][0]['M']
                    s = text.split(' ')
                    cl.findAndAddContactsByMid(inkey)
                    try:
                        for a in range(int(s[2])):
                            cl.createGroup("英豪團隊-邀機測試",[inkey])
                    except:
                        pass
                    c =cl.getGroupIdsByName("英豪團隊-邀機測試")
                    for gid in c:
                        cl.leaveGroup(gid)
 #==============================================================================#
                elif text.lower() == 'me':
                    if msg.toType == 2 or msg.toType == 1:
                        sendMessageWithMention(to, sender)
                        cl.sendContact(to, sender)
                    else:
                        cl.sendContact(to,sender)
                elif "c:" in msg.text:
                    number = text.replace("c:","")
                    cl.sendContact(msg.to,number)
                elif text.lower() == 'mymid':
                    cl.sendReplyMessage(msg.id, to, sender)
                elif text.lower() == 'myname':
                    me = cl.getContact(sender)
                    cl.sendReplyMessage(msg.id, to, me.displayName)
                elif text.lower() == 'mybio':
                    me = cl.getContact(sender)
                    cl.sendReplyMessage(msg.id, to,"[個人簽名]\n" + me.statusMessage)
                elif text.lower() == 'mypicture':
                    me = cl.getContact(sender)
                    cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + me.pictureStatus)
                elif text.lower() == 'myvid':
                    me = cl.getContact(sender)
                    cl.sendVideoWithURL(msg.to,"http://dl.profile.line-cdn.net/" + me.pictureStatus + "/vp")
                elif text.lower() == 'mycover':
                    me = cl.getContact(sender)
                    cover = cl.getProfileCoverURL(sender)
                    cl.sendImageWithURL(msg.to, cover)
                
                elif "gc " in msg.text:
                    if msg.toType == 2:
                        key = eval(msg.contentMetadata["MENTION"])
                        u = key["MENTIONEES"][0]["M"]
                        contact = cl.getContact(u)
                        cu = cl.getProfileCoverURL(mid=u)
                        try:
                            cl.sendMessage(msg.to,"名字:\n" + contact.displayName + "\n\n系統識別碼:\n" + contact.mid + "\n\n個性簽名:\n" + contact.statusMessage + "\n\n頭貼網址 :\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n\n封面網址 :\n" + str(cu))
                        except:
                            cl.sendMessage(msg.to,"名字:\n" + contact.displayName + "\n\n系統識別碼:\n" + contact.mid + "\n\n個性簽名:\n" + contact.statusMessage + "\n\n封面網址:\n" + str(cu))
                elif msg.text.lower().startswith("contact "):
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:
                            contact = cl.getContact(ls)
                            mi_d = contact.mid
                            cl.sendContact(msg.to, mi_d)
                elif msg.text.lower().startswith("mid "):
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        ret_ = ""
                        for ls in lists:
                            ret_ += "" + ls
                        cl.sendReplyMessage(msg.id, to, str(ret_))
                elif msg.text.lower().startswith("name "):
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:
                            contact = cl.getContact(ls)
                            cl.sendReplyMessage(msg.id, to, "[ 名字 ]\n" + contact.displayName)
                        for ls in lists:
                            contact = cl.getContact(ls)
                            cl.sendReplyMessage(msg.id, to, "[ 個簽 ]\n" + contact.statusMessage)
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:
                            path = "http://dl.profile.line-cdn.net/" + cl.getContact(ls).pictureStatus
                            cl.sendImageWithURL(msg.to, str(path))
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for ls in lists:
                                path = cl.getProfileCoverURL(ls)
                                cl.sendImageWithURL(msg.to, str(path))
                elif "sc:" in msg.text:
                    ggid = msg.text.replace("sc:","")
                    group = cl.getGroup(ggid)
                    try:
                        gCreator = group.creator.displayName
                    except:
                        gCreator = "不明"
                    if group.invitee is None:
                        gPending = "0"
                    else:
                        gPending = str(len(group.invitee))
                    if group.preventedJoinByTicket == True:
                        gQr = "關閉"
                        gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(group.id)))
                    else:
                        gQr = "開啟"
                        gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(group.id)))
                    path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                    ret_ = "╔════[群組資料]"
                    ret_ += "\n╠顯示名稱 : {}".format(str(group.name))
                    ret_ += "\n╠群組ＩＤ : {}".format(group.id)
                    ret_ += "\n╠群組作者 : {}".format(str(gCreator))
                    ret_ += "\n╠成員數量 : {}".format(str(len(group.members)))
                    ret_ += "\n╠邀請數量 : {}".format(gPending)
                    ret_ += "\n╠群組網址 : {}".format(gQr)
                    ret_ += "\n╠群組網址 : {}".format(gTicket)
                    ret_ += "\n╚═══[完]"
                    cl.sendMessage(to, str(ret_))
                    cl.sendImageWithURL(to, path)
#==============================================================================#
                elif msg.text.startswith(".Cn:"):
                    curryname = msg.text.replace(".Cn:","")
                    profile = cl.getProfile()
                    profile.displayName = curryname
                    cl.updateProfile(profile)
                    cl.sendReplyMessage(msg.id,to,"名稱更改為：" + profile.displayName)
                elif msg.text.startswith(".Cb:"):
                    currybio = msg.text.replace(".Cb:","")
                    profile = cl.getProfile()
                    profile.statusMessage = currybio
                    cl.updateProfile(profile)
                    cl.sendReplyMessage(msg.id,to,"個簽更改為：" + profile.statusMessage)
                elif msg.text.startswith("空白名字"):
                    curryname = msg.text.replace(" ")
                    profile = cl.getProfile()
                    profile.displayName = curryname
                    cl.updateProfile(profile)
                    path = "C:\\Users\\sen1213\\Desktop\\botfin\\vpc.jpg"
                    cl.updateProfilePicture(path)
                elif text.lower().startswith('send-tw '):
                    sep = text.split(" ")
                    say = text.replace(sep[0] + " ","")
                    lang = 'zh-tw'
                    tts = gTTS(text=say, lang=lang)
                    tts.save("hasil.mp3")
                    cl.sendAudio(to,"hasil.mp3")
                elif text.lower().startswith('send-en '):
                    sep = text.split(" ")
                    say = text.replace(sep[0] + " ","")
                    lang = 'en'
                    tts = gTTS(text=say, lang=lang)
                    tts.save("hasil.mp3")
                    cl.sendAudio(to,"hasil.mp3")
                elif text.lower().startswith('send-jp '):
                    sep = text.split(" ")
                    say = text.replace(sep[0] + " ","")
                    lang = 'ja'
                    tts = gTTS(text=say, lang=lang)
                    tts.save("hasil.mp3")
                    cl.sendAudio(to,"hasil.mp3")
                elif text.lower().startswith('send-id '):
                    sep = text.split(" ")
                    say = text.replace(sep[0] + " ","")
                    lang = 'id'
                    tts = gTTS(text=say, lang=lang)
                    tts.save("hasil.mp3")
                    cl.sendAudio(to,"hasil.mp3")
                elif text.lower().startswith('tr-tw '):
                    sep = text.split(" ")
                    isi = text.replace(sep[0] + " ","")
                    translator = Translator()
                    hasil = translator.translate(isi, dest='zh-tw')
                    A = hasil.text
                    cl.sendMessage(to, A)
                elif text.lower().startswith('tr-en '):
                    sep = text.split(" ")
                    isi = text.replace(sep[0] + " ","")
                    translator = Translator()
                    hasil = translator.translate(isi, dest='en')
                    A = hasil.text
                    cl.sendMessage(to, A)
                elif text.lower().startswith('tr-jp '):
                    sep = text.split(" ")
                    isi = text.replace(sep[0] + " ","")
                    translator = Translator()
                    hasil = translator.translate(isi, dest='ja')
                    A = hasil.text
                    cl.sendMessage(to, A)
                elif text.lower().startswith('tr-id '):
                    sep = text.split(" ")
                    isi = text.replace(sep[0] + " ","")
                    translator = Translator()
                    hasil = translator.translate(isi, dest='id')
                    A = hasil.text
                    cl.sendMessage(to, A)
#==============================================================================#
                elif text.lower() == 'group':
                    group = cl.getGroup(to)
                    GS = group.creator.mid
                    cl.sendContact(to, GS)
                elif text.lower() == 'groupid':
                    gid = cl.getGroup(to)
                    cl.sendMessage(to, "[群組mid : ]\n" + gid.id)
                elif text.lower() == 'grouppicture':
                    group = cl.getGroup(to)
                    path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                    cl.sendImageWithURL(to, path)
                elif text.lower() == 'groupname':
                    gid = cl.getGroup(to)
                    cl.sendMessage(to, "[群組名稱 : ]\n" + gid.name)
                elif text.lower() == 'grouplink':
                    if msg.toType == 2:
                        group = cl.getGroup(to)
                        if group.preventedJoinByTicket == False:
                            ticket = cl.reissueGroupTicket(to)
                            cl.sendMessage(to, "[ 群組網址 ]\nhttps://line.me/R/ti/g/{}".format(str(ticket)))
                        else:
                            cl.sendMessage(to, "Grouplink未開啟 {}openlink".format(str(settings["keyCommand"])))
                elif text.lower() == 'link on':
                    if msg.toType == 2:
                        group = cl.getGroup(to)
                        if group.preventedJoinByTicket == False:
                            cl.sendReplyMessage(msg.id, to, "群組網址已開")
                        else:
                            group.preventedJoinByTicket = False
                            cl.updateGroup(group)
                            cl.sendReplyMessage(msg.id, to, "開啟成功")
                elif text.lower() == 'link off':
                    if msg.toType == 2:
                        group = cl.getGroup(to)
                        if group.preventedJoinByTicket == True:
                            cl.sendReplyMessage(msg.id, to, "群組網址已關")
                        else:
                            group.preventedJoinByTicket = True
                            cl.updateGroup(group)
                            cl.sendReplyMessage(msg.id, to, "關閉成功")
                elif text.lower() == 'ginfo':
                    group = cl.getGroup(to)
                    try:
                        gCreator = group.creator.displayName
                    except:
                        gCreator = "不明"
                    if group.invitee is None:
                        gPending = "0"
                    else:
                        gPending = str(len(group.invitee))
                    if group.preventedJoinByTicket == True:
                        gQr = "關閉"
                        gTicket = "無"
                    else:
                        gQr = "開啟"
                        gTicket = "https://cl.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(group.id)))
                    path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                    ret_ = "[ 群組資料 ]"
                    ret_ += "\n☆群組名稱 : {}".format(str(group.name))
                    ret_ += "\n☆群組 Id : {}".format(group.id)
                    ret_ += "\n☆創建者 : {}".format(str(gCreator))
                    ret_ += "\n☆群組人數 : {}".format(str(len(group.members)))
                    ret_ += "\n☆邀請中 : {}".format(gPending)
                    ret_ += "\n☆網址狀態 : {}".format(gQr)
                    ret_ += "\n☆群組網址 : {}".format(gTicket)
                    ret_ += "\n[ 完 ]"
                    cl.sendReplyMessage(msg.id, to, str(ret_))
                    cl.sendImageWithURL(to, path)
                elif text.lower() == 'gb':
                    if msg.toType == 2:
                        group = cl.getGroup(to)
                        ret_ = "[ 成員名單 ]"
                        no = 0 + 1
                        for mem in group.members:
                            ret_ += "\n☆{}. 名稱：{}".format(str(no), str(mem.displayName))
                            no += 1
                        ret_ += "\n[ 全部成員共 {} 人]".format(str(len(group.members)))
                        cl.sendReplyMessage(msg.id, to, str(ret_))
                elif text.lower() == 'lg':
                        groups = cl.groups
                        ret_ = "[ 群組名單 ]"
                        no = 0 + 1
                        for gid in groups:
                            group = cl.getGroup(gid)
                            ret_ += "\n☆{}.群名 {} | {} 人".format(str(no), str(group.name), str(len(group.members)))
                            no += 1
                        ret_ += "\n[ 共有 {} 的群組 ]".format(str(len(groups)))
                        cl.sendReplyMessage(msg.id, to, str(ret_))
                elif msg.text.lower().startswith("nk "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            cl.sendMessage(to,"88~有緣再見")
                            cl.kickoutFromGroup(msg.to,[target])
                        except:
                            cl.sendMessage(to,"規制中")
                            
                elif msg.text.lower().startswith("tk "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            cl.kickoutFromGroup(msg.to,[target])
                        except:
                            cl.sendMessage(to,"規制中")
                
                elif "Zk" in msg.text:
                    gs = cl.getGroup(to)
                    targets = []
                    for g in gs.members:
                        if g.displayName in "":
                            targets.append(g.mid)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            if target in admin:
                                pass
                            else:
                                try:
                                    cl.kickoutFromGroup(to,[target])
                                except:
                                    pass

                elif msg.text.lower().startswith("ri "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            cl.sendMessage(to,"來回機票一張")
                            cl.kickoutFromGroup(msg.to,[target])
                            cl.inviteIntoGroup(to,[target])
                        except:
                            cl.sendMessage(to,"規制中")
                            
                elif msg.text.lower().startswith("rk "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            cl.kickoutFromGroup(msg.to,[target])
                            cl.inviteIntoGroup(to,[target])
                        except:
                            cl.sendMessage(to,"規制中")
                elif text.lower() == 'bot':
                    cl.sendMessage(to, "我的作者：")
                    cl.sendContact(to, "ueeb9eff8fe4804ea3e25a5d90b09fa7d")
                elif text.lower() == 'byeall':
                    if msg.toType == 2:
                        print ("[ 19 ] KICK ALL MEMBER")
                        _name = msg.text.replace("Byeall","")
                        gs = cl.getGroup(msg.to)
                        cl.sendMessage(msg.to,"破壞降臨")
                        targets = []
                        for g in gs.members:
                            if _name in g.displayName:
                                targets.append(g.mid)
                        if targets == []:
                            cl.sendMessage(msg.to,"指令錯誤")
                        else:
                            for target in targets:
                                try:
                                    cl.kickoutFromGroup(msg.to,[target])
                                    print (msg.to,[g.mid])
                                except:
                                    cl.sendMessage(msg.to,"")
                elif ("Gn " in msg.text):
                    if msg.toType == 2:
                        X = cl.getGroup(msg.to)
                        X.name = msg.text.replace("Gn ","")
                        cl.updateGroup(X)
                    else:
                        cl.sendMessage(msg.to,"It can't be used besides the group.")
                elif text.lower() == 'cancel':
                    if msg.toType == 2:
                        group = cl.getGroup(to)
                        gMembMids = [contact.mid for contact in group.invitee]
                    for _mid in gMembMids:
                        cl.cancelGroupInvitation(msg.to,[_mid])
                    cl.sendReplyMessage(msg.id, to,"已取消所有邀請!")
                elif ("Inv " in msg.text):
                    if msg.toType == 2:
                        midd = msg.text.replace("Inv ","")
                        cl.findAndAddContactsByMid(midd)
                        cl.inviteIntoGroup(to,[midd])
                elif msg.text.lower().startswith("mall "):
                    MENTION = eval(msg.contentMetadata['MENTION'])
                    inkey = MENTION['MENTIONEES'][0]['M']
                    x = text.split(' ',2)
                    c = int(x[2])
                    group = cl.getGroup(to)
                    gMembMids = [contact.mid for contact in group.members]
                    for c in range(c):
                        cl.inviteIntoGroupCall(to.inkey,gMembMid,1)
                elif text.lower().startswith('call:'):
                    if msg.toType == 2:
                        number = msg.text.replace("call:","")
                        group = cl.getGroup(to)
                        gMembMids = [contact.mid for contact in group.members]
                        num = int(number)
                        for var in range(0,num):
                            cl.inviteIntoGroupCall(to,gMembMids,1)
                elif text.lower().startswith('rall:'):
                    if msg.toType == 1:
                        number = msg.text.replace("rall:","")
                        room = cl.getRoom(to)
                        rMembMids = [contact.mid for contact in room.contacts]
                        num = int(number)
                        for var in range(0,num):
                            cl.inviteIntoGroupCall(to,rMembMids,1)
#==============================================================================#
                elif text.lower() == 'tagall':
                    group = cl.getGroup(msg.to)
                    nama = [contact.mid for contact in group.members]
                    k = len(nama)//20
                    for a in range(k+1):
                        txt = u''
                        s=0
                        b=[]
                        for i in group.members[a*20 : (a+1)*20]:
                            b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                            s += 7
                            txt += u'@Alin \n'
                        cl.sendMessage(to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                elif text.lower() == 'zt':
                    gs = cl.getGroup(to)
                    targets = []
                    for g in gs.members:
                        if g.displayName in "":
                            targets.append(g.mid)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            sendMessageWithMention(to,target)
                elif text.lower() == 'zm':
                    gs = cl.getGroup(to)
                    targets = []
                    for g in gs.members:
                        if g.displayName in "":
                            targets.append(g.mid)
                    if targets == []:
                        pass
                    else:
                        for mi_d in targets:
                           cl.sendContect(to,mi_d)
                elif msg.text in ["SR","Setread"]:
                    cl.sendReplyMessage(msg.id, to, "設置已讀點 ✔")
                    try:
                        del wait2['readPoint'][msg.to]
                        del wait2['readMember'][msg.to]
                    except:
                        pass
                    now2 = datetime.now()
                    wait2['readPoint'][msg.to] = msg.id
                    wait2['readMember'][msg.to] = ""
                    wait2['setTime'][msg.to] = datetime.strftime(now2,"%H:%M:%H")
                    wait2['ROM'][msg.to] = {}
                    print ("設置已讀點")
                elif msg.text in ["DR","Delread"]:
                    cl.sendReplyMessage(msg.id, to, "刪除已讀點 ✘")
                    try:
                        del wait2['readPoint'][msg.to]
                        del wait2['readMember'][msg.to]
                        del wait2['setTime'][msg.to]
                    except:
                        pass
                elif msg.text in ["LR","Lookread"]:
                    if msg.to in wait2['readPoint']:
                        print ("查詢已讀")
                        if wait2["ROM"][msg.to].items() == []:
                            chiya = ""
                        else:
                            chiya = ""
                            for rom in wait2["ROM"][msg.to].items():
                                chiya += rom[1] + "\n"
                        cl.sendReplyMessage(msg.id, to, "[已讀順序]:%s\n\n[已讀過的人]:\n%s\n查詢時間:[%s]" % (wait2['readMember'][msg.to],chiya,setTime[msg.to]))
                    else:
                        cl.sendReplyMessage(msg.id, to, "請輸入SR設置已讀點")

#==============================================================================#
                elif msg.text.lower().startswith("ban "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            ban["blacklist"][target] = True
                            cl.sendReplyMessage(msg.id, to,"Ok")
                            break
                        except:
                            cl.sendReplyMessage(msg.id, to,"Nobe")
                            break
                elif "Ban:" in msg.text:
                    mmtxt = text.replace("Ban:","")
                    try:
                        ban["blacklist"][mmtext] = True
                        cl.sendReplyMessage(msg.id, to,"已加入黑單!")
                    except:
                        cl.sendReplyMessage(msg.id, to,"Ok")
                elif msg.text.lower().startswith("unban "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            del ban["blacklist"][target]
                            cl.sendReplyMessage(msg.id, to,"刪除成功 !")
                            break
                        except:
                            cl.sendReplyMessage(msg.id, to,"刪除失敗 !")
                            break
                elif "Mb:" in msg.text:
                    midd = msg.text.replace("Mb:","")
                    try:
                        settings["blacklist"][midd] = True
                        backupData()
                        cl.sendMessage(to, "已加入黑名單")
                    except:
                        pass
                elif "Mub:" in msg.text:
                    midd = msg.text.replace("Mub:","")
                    try:
                        del settings["blacklist"][midd]
                        backupData()
                        cl.sendMessage(to, "已解除黑名單")
                    except:
                        pass
                elif text.lower() == 'banlist':
                    if ban["blacklist"] == {}:
                        cl.sendReplyMessage(msg.id, to,"無黑單成員!")
                    else:
                        mc = "[ Black List ]"
                        for mi_d in ban["blacklist"]:
                            mc += "\n☆"+cl.getContact(mi_d).displayName
                        cl.sendReplyMessage(msg.id, to,mc + "\n[ Finish ]")
                elif msg.text.lower().startswith("k "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            ban["kill"][target] = True
                            cl.sendReplyMessage(msg.id, to,"加入成功")
                            break
                        except:
                            cl.sendReplyMessage(msg.id, to,"無")
                            break
                elif text.lower().startswith("kn "):
                    if msg.toType == 2:
                        _name = msg.text.replace("kn ","")
                        gs = cl.getGroup(msg.to)
                        targets = []
                        for g in gs.members:
                            if _name in g.displayName:
                                targets.append(g.mid)
                        if targets == []:
                            cl.sendMessage(msg.to,"無")
                        else:
                            for target in targets:
                                try:
                                    ban["kill"][target] = True
                                    cl.sendReplyMessage(msg.id, to,"已經新增自預備名單")
                                    break
                                except:
                                    cl.sendReplyMessage(msg.id, to,"Nobe")
                                    break
                elif msg.text.lower().startswith("unk "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            del ban["kill"][target]
                            cl.sendReplyMessage(msg.id, to,"刪除成功 !")
                            break
                        except:
                            cl.sendReplyMessage(msg.id, to,"刪除失敗 !")
                            break
                elif text.lower() == 'klist':
                    if ban["kill"] == {}:
                        cl.sendReplyMessage(msg.id, to,"無預備成員!")
                    else:
                        mc = "[ 預備踢人名單 ]"
                        for mi_d in ban["kill"]:
                            mc += "\n☆"+cl.getContact(mi_d).displayName
                        cl.sendReplyMessage(msg.id, to,mc + "\n[ 已經幫你查詢完畢 ]")
                elif text.lower() == 'us':
                    try:
                        cl.unsendMessage(msg.sendReplyMessageId)
                    except Exception as e:
                        cl.sendMessage(to, "")
                elif text.lower() == 'killgo':
                    if msg.toType == 2:
                        group = cl.getGroup(to)
                        gMembMids = [contact.mid for contact in group.members]
                        matched_list = []
                    for tag in ban["kill"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        cl.sendMessage(msg.to,"已經踢出預備名單")
                        return
                    for jj in matched_list:
                        cl.kickoutFromGroup(msg.to,[jj])
                elif text.lower() == 'nkban':
                    if msg.toType == 2:
                        group = cl.getGroup(to)
                        gMembMids = [contact.mid for contact in group.members]
                        matched_list = []
                    for tag in ban["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        cl.sendMessage(msg.to,"There was no blacklist user")
                        return
                    for jj in matched_list:
                        cl.kickoutFromGroup(msg.to,[jj])
                    cl.sendMessage(msg.to,"Blacklist kicked out")
                elif text.lower() == 'cleankill':
                    for mi_d in ban["kill"]:
                        ban["kill"] = {}
                    cl.sendReplyMessage(msg.id, to, "已清空預備踢人")
                elif text.lower().startswith("tnk:"):
                        separate = text.split(":")
                        _name = text.replace(separate[0] + ":","")
                        gs = cl.getGroup(msg.to)
                        targets = []
                        for g in gs.members:
                            if _name in g.displayName:
                                targets.append(g.mid)
                        if targets == []:
                            cl.relatedMessage(msg.to,"群組內沒有這個名稱")
                        else:
                            for target in targets:
                                try:
                                    cl.kickoutFromGroup(msg.to,[target])
                                except:
                                    pass
                elif text.lower().startswith("公告:"):
                        separate = text.split(":")
                        a = text.replace(separate[0] + ":","")
                        c = ChatRoomAnnouncementContents()
                        c.displayFields = 5
                        c.text = a
                        c.link = "line://nv/chatMsg?chatId={}&messageId={}".format(to,msg.id)
                        try:            
                            cl.createChatRoomAnnouncement(to, 0, c)
                            sendMention(to, "成功新增公告 by. @!", [sender])
                        except Exception as e:
                            cl.sendMessage(to, str(e))
                elif text.lower() in ['logout']:
                    cl.sendMessage(to, "直接登出請輸入[登出][Y]\n手動登出請輸入[手動][N]")	
                    wait['logout'][msg.to] = sender
                elif text.lower() in ["登出","y","Y","N","n","手動"]:
                    if msg.to in wait['logout'] and msg._from== wait['logout'][msg.to]:
                        if text.lower() in ["登出","y","Y"]:
                            cl.sendMessage(to, "將自動幫您登出機器")	
                            cl.sendMessage(to,"[提示]\n已經自動登出後台伺服器")	
                            os._exit(0)	
                            del wait['logout'][msg.to]
                        elif text.lower() in ["N","n","手動"]:
                            cl.sendMessage(to, "請點擊以下網址\nline://nv/connectedDevices/\n進行手動登出")	
                            del wait['logout'][msg.to]
                elif text.lower() == 'killlist':
                    if ban["kill"] == {}:
                        cl.sendReplyMessage(msg.id, to,"無預備成員")
                    else:
                        mc = "[ 預備成員mid ]"
                        for mi_d in ban["kill"]:
                            mc += "\n☆"+mi_d
                        cl.sendReplyMessage(msg.id, to,mc + "\n[ 已經幫你查詢完畢 ]")
                elif text.lower() == 'cleanban':
                    for mi_d in ban["blacklist"]:
                        ban["blacklist"] = {}
                    cl.sendReplyMessage(msg.id, to, "已清空黑名單")
                elif text.lower() == 'banmidlist':
                    if ban["blacklist"] == {}:
                        cl.sendReplyMessage(msg.id, to,"無黑單成員!")
                    else:
                        mc = "[ 黑單 ]"
                        for mi_d in ban["blacklist"]:
                            mc += "\n☆"+mi_d
                        cl.sendReplyMessage(msg.id, to,mc + "\n[ Finish ]")
#==============================================================================#
                elif "好友廣播：" in msg.text:
                    bctxt = text.replace("好友廣播：","")
                    t = cl.getAllContactIds()
                    for manusia in t:
                        cl.sendMessage(manusia,(bctxt))
                elif "群組廣播：" in msg.text:
                    bctxt = text.replace("群組廣播：","")
                    n = cl.getGroupIdsJoined()
                    for manusia in n:
                        cl.sendMessage(manusia,(bctxt))
                elif "Copy " in msg.text:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            contact = cl.getContact(target)
                            X = contact.displayName
                            profile = cl.getProfile()
                            profile.displayName = X
                            cl.updateProfile(profile)
                            cl.sendMessage(to, "Success...")
                            Y = contact.statusMessage
                            lol = cl.getProfile()
                            lol.statusMessage = Y
                            cl.updateProfile(lol)
                            path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            P = contact.pictureStatus
                            cl.updateProfilePicture(P)
                        except Exception as e:
                            cl.sendMessage(to, "Failed!")
            if text.lower() == 'cc9487':
                if sender in ['u6d2b347434d7fabfb0b5b1ae4df9e9c1']:
                    python = sys.executable
                    os.execl(python, python, *sys.argv)
                else:
                    pass
#==============================================================================#
            if msg.contentType == 13:
                if settings["getmid"] == True:
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"[mid]:\n" + msg.contentMetadata["mid"])
                    else:
                        cl.sendMessage(msg.to,"[mid]:\n" + msg.contentMetadata["mid"])
            elif msg.contentType == 16:
                if settings["timeline"] == True:
                    msg.contentType = 0
                    msg.text = "文章網址：\n" + msg.contentMetadata["postEndUrl"]
                  #  detail = cl.downloadFileURL(to,msg,msg.contentMetadata["postEndUrl"])
                    cl.sendMessage(msg.to,msg.text)
#==============================================================================#
        if op.type == 26:
            try:
                msg = op.message
                if settings["reread"] == True:
                    if msg.toType == 0:
                        cl.log("[%s]"%(msg._from)+msg.text)
                    else:
                        cl.log("[%s]"%(msg.to)+msg.text)
                    if msg.contentType == 0:
                        msg_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
                else:
                    pass
            except Exception as e:
                print(e)
        if op.type == 65:
            try:
                at = op.param1
                msg_id = op.param2
                if settings["reread"] == True:
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"] not in bl:
                            cl.sendMessage(at,"[收回訊息者]\n%s\n[收回內容]\n%s"%(cl.getContact(msg_dict[msg_id]["from"]).displayName,msg_dict[msg_id]["text"]))
                            print ("收回訊息")
                        del msg_dict[msg_id]
                else:
                    pass
            except Exception as e:
                print(e)
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
                if settings["autoRead"] == True:
                    cl.sendChatChecked(to, msg_id)
                if to in read["readPoint"]:
                    if sender not in read["ROM"][to]:
                        read["ROM"][to][sender] = True
                if msg.contentType == 0 and sender not in clMID and msg.toType == 2:
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if clMID in mention["M"]:
                                if settings["detectMention"] == False:
                                    contact = cl.getContact(sender)
                                    cl.sendMessage(to, "幹你娘標記我要幹嘛?\n操你媽的死人")
                                    sendMessageWithMention(to, contact.mid)
        if op.type == 55:
            try:
                print("[55]收到他人已讀訊息")
                if op.param1 in read['readPoint']:
                    if op.param2 in read['readMember'][op.param1]:
                        pass
                    else:
                        read['readMember'][op.param1] += op.param2
                    read['ROM'][op.param1][op.param2] = op.param2
                    backupData()
                else:
                   pass
            except:
                pass
            try:
                if op.param1 in wait2['readPoint']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in wait2['readMember'][op.param1]:
                        pass
                    else:
                        wait2['readMember'][op.param1] += "\n[★]" + Name
                        wait2['ROM'][op.param1][op.param2] = "[★]" + Name
                        print (time.time() + Name)
                else:
                    pass
            except:
                pass
    except Exception as error:
        logError(error)
while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                lineBot(op)
                oepoll.setRevision(op.revision)
    except Exception as e:
        logError(e)